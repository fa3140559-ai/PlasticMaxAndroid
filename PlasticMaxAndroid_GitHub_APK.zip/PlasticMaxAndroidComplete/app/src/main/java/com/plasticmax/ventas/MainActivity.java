package com.plasticmax.ventas;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
  DB db; ArrayList<DB.CartItem> cart=new ArrayList<>(); TextView summary,cartView; EditText barcode,qty;
  String money(double x){return String.format(Locale.US,"Gs. %.0f",x);}
  protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);db=new DB(this);summary=findViewById(R.id.tvSummary);cartView=findViewById(R.id.tvCart);barcode=findViewById(R.id.etBarcode);qty=findViewById(R.id.etQty);refresh();
    findViewById(R.id.btnScan).setOnClickListener(v->startActivityForResult(new Intent(this,ScannerActivity.class),10));
    findViewById(R.id.btnNew).setOnClickListener(v->productDialog(null));
    findViewById(R.id.btnProducts).setOnClickListener(v->showProducts());
    findViewById(R.id.btnSales).setOnClickListener(v->showSales());
    findViewById(R.id.btnAddCart).setOnClickListener(v->addByBarcode());
    findViewById(R.id.btnFinish).setOnClickListener(v->finishSale());
    findViewById(R.id.btnBackup).setOnClickListener(v->backup());
  }
  void refresh(){summary.setText("Productos: "+db.count()+"   |   Stock: "+db.stock()+"   |   Ventas: "+money(db.salesTotal()));renderCart();}
  protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK&&d!=null){barcode.setText(d.getStringExtra("barcode"));addByBarcode();}}
  void addByBarcode(){String b=barcode.getText().toString().trim();if(b.isEmpty()){toast("Escribí o escaneá un código");return;}DB.Product p=db.find(b);if(p==null){new AlertDialog.Builder(this).setTitle("Producto no encontrado").setMessage("El código "+b+" no está registrado.").setPositiveButton("Crear producto",(x,w)->productDialog(b)).setNegativeButton("Cerrar",null).show();return;}int q=1;try{q=Math.max(1,Integer.parseInt(qty.getText().toString()));}catch(Exception e){}if(q>p.stock){toast("Stock insuficiente. Disponible: "+p.stock);return;}for(DB.CartItem x:cart)if(x.product.id==p.id){x.qty+=q;renderCart();return;}cart.add(new DB.CartItem(p,q));renderCart();}
  void renderCart(){if(cart==null||cart.isEmpty()){cartView.setText("Carrito vacío");return;}StringBuilder s=new StringBuilder();double total=0;for(DB.CartItem x:cart){double sub=x.product.price*x.qty;total+=sub;s.append(x.product.name).append(" x ").append(x.qty).append(" = ").append(money(sub)).append("\n");}s.append("\nTOTAL: ").append(money(total));cartView.setText(s.toString());}
  void finishSale(){if(cart.isEmpty()){toast("El carrito está vacío");return;}double total=0;for(DB.CartItem x:cart)total+=x.product.price*x.qty;new AlertDialog.Builder(this).setTitle("Confirmar venta").setMessage("Total: "+money(total)+"\n¿Cobrar esta venta?").setNegativeButton("Cancelar",null).setPositiveButton("COBRAR",(d,w)->{db.sale(cart);cart.clear();refresh();toast("Venta guardada");}).show();}
  void productDialog(String preset){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(40,10,40,0);EditText b=e("Código de barras",preset);EditText n=e("Nombre del producto",null);EditText p=e("Precio",null);EditText s=e("Stock",null);p.setInputType(2|8192);s.setInputType(2);l.addView(b);l.addView(n);l.addView(p);l.addView(s);new AlertDialog.Builder(this).setTitle("Nuevo producto").setView(l).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{try{db.saveProduct(b.getText().toString().trim(),n.getText().toString().trim(),Double.parseDouble(p.getText().toString()),Integer.parseInt(s.getText().toString()));refresh();toast("Producto guardado");}catch(Exception ex){toast("Completá todos los datos correctamente");}}).show();}
  EditText e(String hint,String val){EditText x=new EditText(this);x.setHint(hint);if(val!=null)x.setText(val);return x;}
  void showProducts(){StringBuilder s=new StringBuilder();for(DB.Product p:db.all())s.append(p.name).append("\nCódigo: ").append(p.barcode).append("  Stock: ").append(p.stock).append("  ").append(money(p.price)).append("\n\n");if(s.length()==0)s.append("No hay productos todavía.");new AlertDialog.Builder(this).setTitle("Productos y stock").setMessage(s.toString()).setPositiveButton("Cerrar",null).show();}
  void showSales(){StringBuilder s=new StringBuilder();SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault());for(DB.Sale x:db.sales())s.append(f.format(new Date(x.date))).append("  ").append(money(x.total)).append("\n");if(s.length()==0)s.append("No hay ventas todavía.");new AlertDialog.Builder(this).setTitle("Historial de ventas").setMessage(s.toString()).setPositiveButton("Cerrar",null).show();}
  void backup(){StringBuilder s=new StringBuilder("PLÁSTIC MAX - RESPALDO\n\nPRODUCTOS\n");for(DB.Product p:db.all())s.append(p.barcode).append(";").append(p.name).append(";").append(p.price).append(";").append(p.stock).append("\n");Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s.toString());startActivity(Intent.createChooser(i,"Guardar/enviar respaldo"));}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
