package com.plasticmax.ventas;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DB extends SQLiteOpenHelper {
  public DB(Context c){super(c,"plasticmax.db",null,1);}
  public void onCreate(SQLiteDatabase d){
    d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT UNIQUE, name TEXT NOT NULL, price REAL NOT NULL, stock INTEGER NOT NULL DEFAULT 0)");
    d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, date INTEGER NOT NULL, total REAL NOT NULL)");
    d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, product_id INTEGER, qty INTEGER, price REAL)");
  }
  public void onUpgrade(SQLiteDatabase d,int o,int n){}
  public Product find(String b){Cursor c=getReadableDatabase().query("products",null,"barcode=?",new String[]{b},null,null,null);try{if(c.moveToFirst())return new Product(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getInt(4));return null;}finally{c.close();}}
  public long saveProduct(String b,String n,double p,int s){ContentValues v=new ContentValues();v.put("barcode",b);v.put("name",n);v.put("price",p);v.put("stock",s);Product old=find(b);if(old==null)return getWritableDatabase().insert("products",null,v);return getWritableDatabase().update("products",v,"barcode=?",new String[]{b});}
  public List<Product> all(){List<Product> r=new ArrayList<>();Cursor c=getReadableDatabase().query("products",null,null,null,null,null,"name COLLATE NOCASE");try{while(c.moveToNext())r.add(new Product(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getInt(4)));}finally{c.close();}return r;}
  public int count(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM products",null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
  public int stock(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(stock),0) FROM products",null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
  public double salesTotal(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales",null);try{c.moveToFirst();return c.getDouble(0);}finally{c.close();}}
  public long sale(List<CartItem> items){SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{double total=0;for(CartItem x:items)total+=x.product.price*x.qty;ContentValues s=new ContentValues();s.put("date",System.currentTimeMillis());s.put("total",total);long id=d.insert("sales",null,s);for(CartItem x:items){ContentValues i=new ContentValues();i.put("sale_id",id);i.put("product_id",x.product.id);i.put("qty",x.qty);i.put("price",x.product.price);d.insert("sale_items",null,i);ContentValues u=new ContentValues();u.put("stock",x.product.stock-x.qty);d.update("products",u,"id=?",new String[]{String.valueOf(x.product.id)});}d.setTransactionSuccessful();return id;}finally{d.endTransaction();}}
  public List<Sale> sales(){List<Sale> r=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,date,total FROM sales ORDER BY date DESC",null);try{while(c.moveToNext())r.add(new Sale(c.getLong(0),c.getLong(1),c.getDouble(2)));}finally{c.close();}return r;}
  public static class Product{long id;String barcode,name;double price;int stock;Product(long i,String b,String n,double p,int s){id=i;barcode=b;name=n;price=p;stock=s;}}
  public static class CartItem{Product product;int qty;CartItem(Product p,int q){product=p;qty=q;}}
  public static class Sale{long id,date;double total;Sale(long i,long d,double t){id=i;date=d;total=t;}}
}
