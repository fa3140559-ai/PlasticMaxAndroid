# Plástic Max Ventas — Android offline

Proyecto Android nativo para Plástic Max · Embalajes.

## Incluye
- Productos con código de barras, nombre, precio y stock.
- Escáner con cámara usando ML Kit y CameraX.
- Carrito y cobro de ventas.
- Historial de ventas.
- Resumen de productos, stock y ventas.
- Respaldo de productos mediante compartir texto.
- Base de datos SQLite local.
- Sin permiso de Internet en el AndroidManifest: el uso normal de la app no necesita datos móviles ni Wi‑Fi.

## Importante sobre el escáner offline
Se usa la dependencia `com.google.mlkit:barcode-scanning:17.3.0`, que empaqueta el modelo dentro de la aplicación. Google documenta que esta modalidad deja el modelo disponible inmediatamente y que el escaneo se realiza en el dispositivo sin conexión de red.

## Compilar
Abrir esta carpeta en Android Studio. El proyecto usa Android Gradle Plugin 9.4.0 y Gradle 9.6.0, con JDK 17 recomendado por la documentación de Android.
Luego: Build > Generate App Bundles or APKs > Generate APKs.

La primera sincronización/compilación de Android Studio puede necesitar Internet para descargar Gradle y dependencias. Una vez instalada, la app no requiere datos para las funciones incluidas.
